#ifndef TEST_CONV_H
#define TEST_CONV_H

void test_conv(void);
// void test_conv2(void);
// void test_conv3(void);
// void test_conv_multi_channel(void);
void test_conv_im2col(void);
void test_conv_kernel_larger_than_image(void);
// void test_conv_with_1x1_kernel(void);

#endif // TEST_CONV_H
