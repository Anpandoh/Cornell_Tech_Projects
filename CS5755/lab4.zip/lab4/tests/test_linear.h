#ifndef TEST_LINEAR_H
#define TEST_LINEAR_H

void test_linear_basic(void);
void test_linear_basic2(void);
void test_linear_basic3(void);
void test_linear_empty_input(void);
void test_linear_zero_weights_biases(void);

#endif /* TEST_LINEAR_H */
