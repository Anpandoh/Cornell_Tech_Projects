#ifndef TEST_MATRIX_OPS_H
#define TEST_MATRIX_OPS_H

void test_matmul_square_matrices(void);
void test_matmul_3x1_by_1x3(void);
void test_matmul_incompatible_dimensions(void);
void test_matmul_512x512(void);
void test_matmul_1024x1024(void);



#endif /* TEST_MATRIX_OPS_H */
