#ifndef LAB1_H
#define LAB1_H

#include "./tests/test_conv.h"
#include "./tests/test_nn.h"
#include "./tests/test_functional.h"
#include "./tests/test_linear.h"
#include "./tests/test_matrix_ops.h"
#include "./tests/unity/unity.h"
#include <stdio.h>

#endif // LAB1_H
