#ifndef TEST_FUNCTIONAL_H
#define TEST_FUNCTIONAL_H

void test_softmax_basic(void);
void test_softmax_edge_cases(void);
void test_softmax_large_values(void);
void test_relu(void);
void test_relu2(void);
void test_relu3(void);



#endif /* TEST_FUNCTIONAL_H */
