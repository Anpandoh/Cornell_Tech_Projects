#ifndef TEST_ATTENTION_H
#define TEST_ATTENTION_H

void test_scaled_dot_product_attention(void);

#endif // TEST_ATTENTION_H